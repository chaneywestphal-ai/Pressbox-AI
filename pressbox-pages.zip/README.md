# PRESSBOX AI — Daily Intelligence Briefing

AI-powered sports betting analysis dashboard. Toggle sports (NBA, MLB, UFC, NHL, NCAAM, NFL) and bet types (Props, Spreads, Moneylines, Totals, Parlays) to generate a custom daily briefing powered by Claude + web search.

## Deploy

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Source: **Deploy from a branch**
4. Branch: `main`, folder: `/docs`
5. Save — site goes live in ~60 seconds

## How It Works

- Select sports and bet types via toggle switches
- Hit **Generate Briefing** to fire a multi-turn Claude API call with live web search
- AI searches for today's schedule, odds, injuries, props, and trends
- Results are tiered (Strong Edge / Moderate / Speculative) with confidence ratings
- Tabs: Picks, Parlays, Digest, Injuries

## Stack

- React 18 (CDN, no build step)
- Babel standalone (in-browser JSX transpilation)
- Claude API with web search tool
- Single HTML file — zero dependencies
