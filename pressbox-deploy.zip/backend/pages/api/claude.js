import { handleCors } from '../../lib/cors.js';

// POST /api/claude — Proxy requests to Anthropic Messages API
// The browser can't call api.anthropic.com directly (no CORS + needs API key)
// This route adds the API key server-side and relays the request
export default async function handler(req, res) {
  if (handleCors(req, res)) return;

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'POST only' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY not configured on server' });
  }

  try {
    const body = req.body;

    // Validate basic structure
    if (!body.messages || !Array.isArray(body.messages)) {
      return res.status(400).json({ error: 'Missing messages array' });
    }

    // Build the Anthropic API request
    const anthropicBody = {
      model: body.model || 'claude-sonnet-4-20250514',
      max_tokens: Math.min(body.max_tokens || 16000, 16000),
      messages: body.messages,
    };

    // Optional fields
    if (body.system) anthropicBody.system = body.system;
    if (body.tools) anthropicBody.tools = body.tools;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(anthropicBody),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json(data);
    }

    return res.status(200).json(data);
  } catch (err) {
    console.error('Claude proxy error:', err);
    return res.status(500).json({ error: err.message });
  }
}
