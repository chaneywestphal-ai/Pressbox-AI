import { handleCors } from '../../lib/cors.js';

export default function handler(req, res) {
  if (handleCors(req, res)) return;
  res.status(200).json({ ok: true, timestamp: new Date().toISOString() });
}
