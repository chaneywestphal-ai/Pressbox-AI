# PRESSBOX AI — Daily Intelligence Briefing

AI-powered sports betting analysis dashboard with toggle controls for sports and bet types.

## Architecture

```
pressbox-deploy/
├── docs/                    ← GitHub Pages (static frontend)
│   ├── .nojekyll            ← Bypass Jekyll processing
│   └── index.html           ← Full React app (CDN, no build step)
├── backend/                 ← Vercel (API proxy)
│   ├── pages/api/
│   │   ├── claude.js        ← Claude API proxy (adds API key server-side)
│   │   └── health.js        ← Health check
│   ├── lib/cors.js          ← CORS headers for cross-origin calls
│   ├── next.config.js
│   └── package.json
└── README.md
```

## Why a Backend?

The Claude API (`api.anthropic.com`) does not allow direct browser calls:
- No CORS headers for browser origins
- Requires an API key that can't be exposed in client-side code

The Vercel backend acts as a thin proxy: the browser calls your Vercel URL, Vercel adds the API key and forwards to Anthropic.

## Deploy Steps

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "PRESSBOX AI deploy"
git remote add origin https://github.com/YOUR-USERNAME/pressbox-ai.git
git push -u origin main
```

### 2. Enable GitHub Pages
- Go to **Settings → Pages**
- Source: **Deploy from a branch**
- Branch: `main`, Folder: `/docs`
- Save — live in ~60 seconds

### 3. Deploy Backend to Vercel
- Go to [vercel.com](https://vercel.com) → **Import Project**
- Select your GitHub repo
- Set **Root Directory** to `backend`
- Add environment variables:
  - `ANTHROPIC_API_KEY` = your Claude API key
  - `FRONTEND_ORIGIN` = `https://YOUR-USERNAME.github.io` (or `*` for testing)
- Deploy

### 4. Connect Frontend to Backend
- Open your GitHub Pages site
- In the **Controls** panel, paste your Vercel URL (e.g., `https://pressbox-ai.vercel.app`)
- It saves to localStorage — you only need to do this once
- Hit **Generate Briefing**

## Get an Anthropic API Key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Create an account / sign in
3. Go to **API Keys** → Create new key
4. Copy the key — add it as `ANTHROPIC_API_KEY` in Vercel

## Features

- **Sport toggles**: NBA, MLB, UFC, NHL, NCAAM, NFL
- **Bet type toggles**: Player Props, Spreads, Moneylines, Totals, Parlays
- **AI-powered analysis**: Multi-turn Claude API calls with live web search
- **Tiered picks**: Strong Edge / Moderate / Speculative with confidence ratings
- **4 tabs**: Picks, Parlays, Digest, Injuries
- **Real-time filters**: Toggle sports and bet types post-generation
